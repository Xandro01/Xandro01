package com.example.mailserver;

public class Util {
    protected static final String RESET_NOTIFY  = "RESETNOTIFY";
    protected static final String HAS_NOTIFY  = "HASNOTIFY";
    protected static final String SEND_ALL_USER  = "SNDALLUSR";
    protected static final String REQUEST_ACCOUNT  = "RQSTACC";
    protected static final String SEND_MSG  = "SNDMSG";
    protected static final String DELEM  = "DLEML";

}
